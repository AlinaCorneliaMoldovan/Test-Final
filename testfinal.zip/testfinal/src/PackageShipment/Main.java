package PackageShipment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Alina Moldovan on 16-Nov-17.
 */
public class Main {
    public static void main(String[] args) {
        // write your code here
        System.out.println("Incepem...");

        // generate a number of packages
        PackageList packageList = new PackageList();

        packageList.add(new Package("Zalau", 80, 100, new Date(2017, 11, 20)));
        packageList.add(new Package("Zalau", 80, 200, new Date(2017, 11, 20)));
        packageList.add(new Package("Zalau", 80, 180, new Date(2017, 11, 21)));
        packageList.add(new Package("Zalau", 80, 250, new Date(2017, 11, 20)));
        packageList.add(new Package("Zalau", 80, 30, new Date(2017, 11, 20)));
        packageList.add(new Package("Zalau", 80, 55, new Date(2017, 11, 19)));

        packageList.add(new Package("Dej", 60, 100, new Date(2017, 11, 20)));
        packageList.add(new Package("Dej", 60, 200, new Date(2017, 11, 20)));
        packageList.add(new Package("Dej", 60, 180, new Date(2017, 11, 21)));
        packageList.add(new Package("Dej", 60, 250, new Date(2017, 11, 20)));

        packageList.add(new Package("Huedin", 50, 30, new Date(2017, 11, 20)));
        packageList.add(new Package("Huedin", 50, 55, new Date(2017, 11, 19)));


        // set delivery paramters
        Date currentDate = new Date(2017, 11, 20);
        int profitPerKm = 1;

        // sort packages by location
        PackageList packagesToDeliver = new PackageList(packageList.getPackages(currentDate));
        packagesToDeliver.sortOnLocation();

        // batch all packages for a location into a transport
        List<PackageTransport> transports = new ArrayList<PackageTransport>();
        PackageTransport transport = null;
        for (Package pack : packagesToDeliver.getPackages()) {
            if (transport != null && !transport.getLocation().equals(pack.getLocation())) {
                transports.add(transport);
                transport = new PackageTransport(pack.getDeliveryDate(), pack.getLocation(), pack.getDistance());
            }
            if (transport == null) {
                transport = new PackageTransport(pack.getDeliveryDate(), pack.getLocation(), pack.getDistance());
            }
            transport.add(pack);
        }
        if (transport != null) {
            transports.add(transport);
        }

        // create trips for each transport
        List<Trip> trips = new ArrayList<Trip>();
        for (PackageTransport t : transports) {
            Trip trip = new Trip(t, profitPerKm);
            trips.add(trip);
        }

        // send all drivers on trips
        for (Trip trip : trips) {
            trip.start();
        }

        // wait for all transports to finish
        for (Trip trip : trips) {
            try {
                trip.join();
            } catch (Exception ex) {

            }
        }
        int totalProfit = 0;
        for (Trip trip : trips) {
            totalProfit += trip.getTransport().getProfit();
        }
        System.out.println("In total am castigat " + totalProfit + " lei");
    }
}

